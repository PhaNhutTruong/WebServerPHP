#ifndef PHP_DB4_H
#define PHP_DB4_H

#if DBA_DB4

#include "php_dba.h"

DBA_FUNCS(db4);

#endif

#endif
